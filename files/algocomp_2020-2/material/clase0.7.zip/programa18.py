# obtendre del usuario el numero de alumnos y de sillas
print("Cuantos alumnos hay?")
alumnos = int(input())
print("Cuantas sillas hay?")
sillas = int(input())
if alumnos <= 5 :
    print("No se va a abrir el grupo")
else :
    if alumnos >= sillas : 
        print("Los alumnos van a estar parados")
    else : 
        print("Todo estara bien !")

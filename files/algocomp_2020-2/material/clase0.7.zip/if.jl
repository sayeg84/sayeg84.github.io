# if basico en julia
println("Dame un primer numero")
a = parse(Float64,readline())
println("Dame un segundo numero")
b = parse(Float64,readline())
if a < b
    println("el segundo es mayor que el primero")
else
    println("el primero es mayor o igual que el segundo")
end
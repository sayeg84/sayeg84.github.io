# ejemplo de sintaxis de un if en python
# este programa compara dos numeros a y b y nos imprime un texto dependiendo de cual es mayor
print("Dame un primer numero")
a = float(input())
print("Dame un segundo numero")
b = float(input())
if a < b :
    print("el primero es menor que el segundo")
else:
    print("el segundo es menor o igual que el primero")
    # esto sigue dentro del else
# esto ya esta afuera
print("linea extra")
# ya estoy fuera
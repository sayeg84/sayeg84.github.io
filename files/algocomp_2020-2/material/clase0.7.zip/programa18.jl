println("Cuantos alumnos?")
alumnos = parse(Int64,readline())
println("Cuantas sillas?")
sillas = parse(Int64,readline())
if alumnos <= 5
    println("No se va a abrir el grupo")
else
    if alumnos >= sillas
        println("Algunos alumnos van a estar parados")
    else
        println("Todo estara bien")
    end
end
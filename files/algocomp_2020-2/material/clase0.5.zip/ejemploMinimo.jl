println("Como te llamas")
name = readline()
println("Hola")
println(name)
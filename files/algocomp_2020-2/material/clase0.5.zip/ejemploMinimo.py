print("Como te llamas?")
name = str(input())
print("Hola")
print(name)
def stringToBool(cad):
    if cad == "True":
        return True
    elif cad == "False":
        return False
    else:
        print("Error")
# Vamos a calcular la tabla de verdad del pizarrón
# Leemos los valores de verdad de cada proposición
print("Dame el valor de P")
P = stringToBool(input())
print("Dame el valor de Q")
Q = stringToBool(input())
print("Dame el valor de R")
R = stringToBool(input())
print("Dame el valor de S")
S = stringToBool(input())
# Calculando variables auxiliares
A = P and Q
B = (not R) or S
C = S or (not Q)
# Calculando el valor final
resultado = A or ((R and C) and B)
print("El valor de la proposición es: ", end="")
print(resultado)
def miFuncion(x):
    v = x**3 - 4*x
    w = np.sin(np.sin(x))
    z = np.exp(v*np.cos(x))*w
    return z
# Este programa tabula la funcion h(x) = ... en un intervalo dado para cierto número de puntos
import numpy as np
print("Dame el valor de a")
a = float(input())
print("Dame el valor de b")
b = float(input())
print("Dame el valor de n")
n = int(input())
xs = np.linspace(a,b,n)
ys = [miFuncion(x) for x in xs]
print("Los valores en x son")
print(xs)
print("Los valores en y son")
print(ys)
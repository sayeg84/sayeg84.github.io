function miFuncion(x)
    v = x^3 - 4*x
    w = sin(sin(x))
    z = exp(v*cos(x)) * w
    return z
end
# Este programa va a tabular la funcion h(x) = ... en un intervalo dado para un número de puntos
println("Dame el valor de a")
a = parse(Float64,readline())
println("Dame el valor de b")
b = parse(Float64,readline())
println("Dame el valor de n")
n = parse(Int64,readline())
xs = range(a,stop=b,length=n)
ys = [miFuncion(x) for x in xs]
println("Los valores en x son")
println(xs)
println("Los valores en y son")
println(ys)
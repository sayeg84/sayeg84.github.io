function saludo(cad)
    print("¡Que ondita ")
    print(cad)
    println("!. Mucho Gusto")
    # Obtener el nombrede las personas
    println("¿Cual es tu nombre?")
end
nom = readline()
println("¿Cual es el nombre de tu primer amigo?")
amigo1 = readline()
println("¿Cual es el nombre de tu segundo amigo?")
amigo2 = readline()

# los saludamos
saludo(nom)
saludo(amigo1)
saludo(amigo2)
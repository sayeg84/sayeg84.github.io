def saludo(cad):
    print("¡Que ondita ",end="")
    print(cad,end="")
    print("!. Mucho Gusto")

# Este programa saludara a tres personas
print("¿Cual es tu nombre?")
nom = str(input())
print("¿Cual es el nombre de tu primer amigo?")
amigo1 = str(input())
print("¿Cual es el nombre de tu segundo amigo?")
amigo1 = str(input())

# Procedemos a saludarlos
saludo(nom)
saludo(amigo1)
saludo(amigo2)
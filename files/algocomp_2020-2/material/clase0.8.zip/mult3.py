# este programa cuenta los multiplos de tres menores a 100
i = 1
while i < 100 :
    # pregundo si es multiplo de 3
    if (i % 3) == 0:
        # lo imprimo
        print(i)
    # voy al siguiente i
    i = i + 1
# salgo de todos lados
# ejemplo basico en julia
x = 1
while x < 5 
    global x
    println("El numero x es menor que cinco")
    x = x + 1
end

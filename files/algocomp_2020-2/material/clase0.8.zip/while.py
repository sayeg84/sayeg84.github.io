# este es el ejemplo basico de un ciclo while
x = 1
while x < 5 :
    print("El numero x es menor que 5")
    x = x + 1
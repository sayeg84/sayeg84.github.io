# este programa imprime los multiplos de 3 menores a 100
i = 1
while i < 10000
    global i 
    if (i % 3) == 0
        println(i)
    end
    i = i + 1
end
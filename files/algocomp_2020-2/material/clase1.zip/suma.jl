# Programa para hacer una suma.
println("Dame el límite de la suma")
n = parse(Int64,readline())
suma = 0
for i in range(1,stop=n)
    global suma
    suma = suma + i
end
print("El valor de la suma dado por el programa es: ")
println(suma)
print("El valor analítico es: ")
println(n*(n+1)/2)
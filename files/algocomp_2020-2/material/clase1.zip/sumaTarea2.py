# Programa para calcular la suma del ejercicio 6 de la tarea 2
import numpy as np
n = 234
suma = 0
for k in range(1,n+1):
    suma = suma + np.sqrt(2*k-1)
print("El valor de la suma es: ",end="")
print(suma)
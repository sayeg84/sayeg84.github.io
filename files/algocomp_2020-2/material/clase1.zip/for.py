print("El ejemplo de un ciclo for")
for i in ["Aldo",3.56,True,9]:
    print("El valor de i es: ",end="")
    print(i)
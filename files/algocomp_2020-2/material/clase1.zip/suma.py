# Programa para hacer una suma
print("Dame el limite de la suma")
n = int(input())
suma = 0
for i in range(1,n+1):
    suma = suma + i
print("El valor calculado por el programa es: ",end="")
print(suma)
print("El valor analitico es: ",end="")
print(n*(n+1)/2)

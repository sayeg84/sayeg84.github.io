# Programa para calcular la suma del ejercicio 6 de la tarea 2
n = 234
suma = 0
for k in range(1,stop=n)
    global suma
    suma = suma + sqrt(2*k-1)
end
print("El valor de la suma es: ")
println(suma)
println("Este programa es el ejemplo de un ciclo for")
for i in ["Aldo",true,9.62,-11]
    print("El valor de i es: ")
    println(i)
end
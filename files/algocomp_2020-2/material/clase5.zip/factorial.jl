function mi_factorial(n)
    if n <=0
        # levantar error si n es negativo
        error("n no debe de ser negativo")
    end
    if n == 1
        return 1
    else
        return mi_factorial(n-1)*n
    end
end
println("Dame un numero natural")
m = parse(Int64,readline())
print("El factorial de numero es ")
println(mi_factorial(m))


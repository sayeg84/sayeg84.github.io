function mi_fibonacci(n)
    if n<=0
        error("n no debe de ser negativo")
    end
    if n == 1
        return 0
    elseif n == 2
        return 1
    else
        return mi_fibonacci(n-2) + mi_fibonacci(n-1)
    end
end
println("Dame un numero natural")
m = parse(Int64,readline())
print("El m-esimo numero de Fibonacci es: ")
println(mi_fibonacci(m))
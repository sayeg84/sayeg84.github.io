def mi_factorial(n):
    if n<=0:
        # Levantar error si n es negativo
        raise ValueError("n no debe de ser negativo")
    if n==1:
        return 1
    else:
        return mi_factorial(n-1)*n
print("Dame un numero natural")
m = int(input())
print("El factorial del numero es ", end="")
print(mi_factorial(m))
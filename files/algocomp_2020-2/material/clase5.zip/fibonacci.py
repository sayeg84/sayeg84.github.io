def mi_fibonacci(n):
    if n<=0:
        raise ValueError("n no debe de ser negativo")
    if n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        return mi_fibonacci(n-2) + mi_fibonacci(n-1)
print("Dame un numero natural")
m = int(input())
print("El m-esimo numero de Fibonacci es ",end="")
print(mi_fibonacci(m))
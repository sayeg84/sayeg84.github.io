# Programa para obtener una lista con la suma de los primeros n naturales en cada entrada
println("Dame el valor de n")
n = parse(Int64,readline())
suma = 0
resul = []
for i in range(1,stop=n)
    global suma
    global resul
    suma = suma + 1
    push!(resul,suma)
end
println("Las sumas son: ")
println(resul)

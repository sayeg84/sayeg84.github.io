# Este programa tabula el polinomio 3x^2 + 6x - 2 en un intervalo dado para cierto número de puntos
import numpy as np
print("Dame el valor de a")
a = float(input())
print("Dame el valor de b")
b = float(input())
print("Dame el valor de n")
n = int(input())
xs = np.linspace(a,b,n)
ys = []
for x in xs:
    y = 3*x**2 + 6*x - 2
    ys.append(y)
print("Los valores en x son")
print(xs)
print("Los valores en y son")
print(ys)
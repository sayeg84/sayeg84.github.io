# Este programa va a tabular la funcion 3x^2 + 6x - 2 en un intervalo dado para un número de puntos
println("Dame el valor de a")
a = parse(Float64,readline())
println("Dame el valor de b")
b = parse(Float64,readline())
println("Dame el valor de n")
n = parse(Int64,readline())
xs = range(a,stop=b,length=n)
ys = []
for x in xs
    y = 3*x^2 + 6*x - 2
    push!(ys,y)
end
println("Los valores en x son")
println(xs)
println("Los valores en y son")
println(ys)
# Programa para obtener una lista con la suma de los primeros n naturales en cada entrada
print("Dame el valor de n")
n = int(input())
suma = 0
resul = []
for i in range(1,n+1):
    suma = suma + 1
    resul.append(suma)
print("Las sumas son: ")
print(resul)

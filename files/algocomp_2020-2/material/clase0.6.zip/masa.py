# comentario inicial
# leemos los valores del usuario
print("Dame la primera masa")
m1 = float(input())
print("Dame la segunda masa")
m2 = float(input())
# calculamos
c = m1 * m2
d = m1 + m2 
mu = c/d
# salimos
print("La masa reducida es:")
print(mu)
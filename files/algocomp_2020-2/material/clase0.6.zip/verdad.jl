# Este programa va a calcular la tabla de verdad del pizarron
#
# Obtenemos los valores de P, Q, R Y S
println("Dame el valor de P")
P = parse(Bool,readline())
println("Dame el valor de Q")
Q = parse(Bool,readline())
println("Dame el valor de R")
R = parse(Bool,readline())
println("Dame el valor de S")
S = parse(Bool,readline())
# Calculamos las proposiciones auxiliares
A = P && Q
B = !R || S
C = S && !Q
# Calculamos el resultado final
final = A || ((R && C) && B)
println("El valor de la proposición es:")
println(final)
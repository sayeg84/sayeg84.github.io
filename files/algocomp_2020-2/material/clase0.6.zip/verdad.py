# vamos a calcular la proposicion dada
# leemos los valores
print("Dame el valor de P")
P = bool(input())
print("Dame el valor de Q")
Q = bool(input())
print("Dame el valor de R")
R = bool(input())
print("Dame el valor de S")
S = bool(input())
# Calculamos las variables auxiliares
A = P and Q
B = not(R) or S
C = S or not(Q)
# calculamos la proposicion
final = A or ((R and C) and B)
print("El valor de la proposicion es:")
print(final)
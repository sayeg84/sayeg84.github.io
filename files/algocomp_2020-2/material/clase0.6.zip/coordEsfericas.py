import numpy as np
# Programa para hacer cambio de coordenadas de esfericas a cartesianas
# leemos los datos
print("Dame el valor de r")
r = float(input())
print("Dame el valor de phi en grados")
phi = float(input())
print("Dame el valor de theta en grados")
theta = float(input())
# Coonvertir los angulos de grados a radianes
phi = np.pi/180 * phi
theta = np.pi/180 * theta
# calculamos el cambio de coordenadas
x = r * np.sin(phi) * np.cos(theta)
y = r * np.sin(phi) * np.sin(theta)
z = r * np.cos(phi)
# imprimimos el valor de las coordenadas
print("las coordenadas x,y,z son:")
print(x)
print(y)
print(z)
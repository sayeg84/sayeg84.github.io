# Programa para calcular la masa reducida
#
# Leemos las masas del usuario
println("Dame la primera masa")
m1 = parse(Float64,readline())
println("Dame la segunda masa")
m2 = parse(Float64,readline())
# Hacemos los calculos
c = m1 * m2
d = m1 + m2
mu = c/d
# Imprimimos el resultado
println("La masa reducida es:")
println(mu)
# haremos un cambio de coordenadas esfericas a cartesianas 
# leemos los datos
println("Dame el valor de r")
r = parse(Float64,readline())
println("Dame el valor de phi en grados")
phi = parse(Float64,readline())
println("Dame el valor de theta en grados")
theta = parse(Float64,readline())
# cambiamos los angulos a radianes
phi = pi/180 * phi
theta = pi/180 * theta
# calculamos las coordenadas
x = r * sin(phi) * cos(theta)
y = r * sin(phi) * sin(theta)
z = r * cos(phi)
# imprimimos los resultados
println("Las coordenadas x,y,z son:")
println(x)
println(y)
println(z)

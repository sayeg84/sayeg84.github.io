# Este programa checa si un numero es primo o no
println("Dame el número que queremos probar")
n = parse(Int64,readline())
prim = true
for i in range(2,stop=n-1)
    global prim
    if n % i == 0
        prim = false
    end
end
if prim
    print(n)
    println(" es primo")
else
    print(n)
    println(" no es primo")
end
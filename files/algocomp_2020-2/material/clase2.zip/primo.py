# Este programa verifica si un numero es primo
print("Dame el número que queremos probar: ")
n = int(input())
prim = True
# Iteramos desde 2 hasta n-1 buscando divisores
for i in range(2,n):
    #Si encontramos un divisor, cambiar a la variable prim
    if n % i == 0:
        prim = False
# Imprimir mensaje dependiendo si es primo o no
if prim:
    print(n, end="")
    print(" es primo")
else:
    print(n, end="")
    print(" no es primo")



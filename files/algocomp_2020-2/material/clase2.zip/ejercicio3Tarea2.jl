# Programa correspondiente al ejercicio 3 de la tarea 2
# Obtenemos x y x del usurio
println("Dame el valor de x")
x = parse(Float64,readline())
println("Dame el valor de y")
y = parse(Float64,readline())
n = 2
while n <= y 
    global n 
    global x
    print("El valor de n es: ")
    println(n)
    print("El valor de x es: ")
    println(x)
    n = n + x
    x = x - 0.1
    println("Aca seguimos")
end
println(n)
println(x)
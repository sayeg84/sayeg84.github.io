# Programa correspondiente al algoritmo 3 de la tarea 2
# Obtenemos el valor de x y y  del usuario
print("Dame el valor de x")
x = float(input())
print("Dame el valor de y")
y = float(input())
n = 2
while n <= y:
    print("El valor de n es: ")
    print(n)
    print("El valor de x es: ")
    print(x)
    n = n + x
    x = x - 0.1
    print("Aca seguimos")
print(n)
print(x)